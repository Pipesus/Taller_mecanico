<?php
    define('URL', 'http://localhost:8080/tallermecanico');
    //define('URL', 'http://localhost:8080/');
    
    define('HOST', 'localhost');
    define('DB', 'Taller');
    define('USER', 'pipesus');
    define('PASSWORD', 'sonimisan446441');
    define('CHARSET', 'utf8mb4_unicode_ci');
?>