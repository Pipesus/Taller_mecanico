<?php

class UserModel extends Model implements IModel{

    private $id;
    private $username;
    private $password;
    private $correo;
    private $estado;
    private $rol_id;
    //TODO lista vehiculos y todo manejarlo desde el vehiculo

    public function __construct(){
        parent::__construct();

        $this->username = '';
        $this->password = '';
        $this->correo = '';
        $this->estado = 1;
        $this->rol_id = 1;
    }

    function updateName($name, $iduser){
        try {
            $query = $this->db->connect()->prepare('UPDATE usuario SET username = :val WHERE id = :id');
            $query->execute(['val' => $name, 'id' => $iduser]);

            if($query->rowCount() > 0){
                return true;
            }else{
                return false;
            }
        
        }catch(PDOException $e){
            return NULL;
        }
    }

    function updatePassword($new, $iduser){
        try {
            $hash = password_hash($new, PASSWORD_DEFAULT, ['cost' => 10]);
            $query = $this->db->prepare('UPDATE usuario SET password = :val WHERE id = :id');
            $query->execute(['val' => $hash, 'id' => $iduser]);
            
            if($query->rowCount() > 0){
                return true;
            }else{
                return false;
            }
        
        }catch(PDOException $e){
            return NULL;
        }

    }

    function comparePasswords($current, $userid){
        try{
            $query = $this->db->connect()->prepare('SELECT id, password FROM usuario WHERE id = :id');
            $query->execute(['id' => $userid]);
            
            if($row = $query->fetch(PDO::FETCH_ASSOC)) return password_verify($current, $row['password']);

            return NULL;
        }catch(PDOException $e){
            return NULL;
        }
    }

    public function save(){
        try {
            $query = $this->prepare('INSERT INTO usuario (username, password, correo, rol_id) VALUES (:username, :password, :correo, :rol_id)');
            $query->execute([
                'username'  => $this->username, 
                'password'  => $this->password, 
                'correo'    => $this->correo, 
                'rol_id'    => $this->rol_id 
                ]);
            return true;
        }catch(PDOException $e){
            echo $e;
            return false;
        }
    }

    public function getAll(){
        $items = [];

        try{
            $query = $this->query('SELECT * FROM usuario');
            
            while ($p = $query->fetch(PDO::FETCH_ASSOC)){
                $item = new UserModel();
                
                $item->setId($p['id']);
                $item->setUsername($p['username']);
                $item->setPassword($p['password'], false);
                $item->setCorreo($p['correo']);
                $item->setEstado($p['estado']);
                $item->setRol_id($p['rol_id']); 
                array_push($items, $item);
                
            }
            return $items;
        
        }catch(PDOException $e){
            echo $e;
        }
    }

    /**
     *  Gets an item
     */
    public function get($id){
        try{
            $query = $this->prepare('SELECT * FROM usuario WHERE id = :id');
            $query->execute([ 'id' => $id]);
            $user = $query->fetch(PDO::FETCH_ASSOC);

            $this->id = $user['id'];
            $this->username = $user['username'];
            $this->password = $user['password'];
            $this->correo = $user['correo'];
            $this->estado = $user['estado'];
            $this->rol_id = $user['rol_id'];

            return $this;
        }catch(PDOException $e){
            return false;
        }
    }

    public function delete($id){
        try{
            $query = $this->prepare('DELETE FROM usuario WHERE id = :id');
            $query->execute([ 'id' => $id]);
            return true;
        }catch(PDOException $e){
            echo $e;
            return false;
        }
    }

    public function update(){
        try{
            $query = $this->prepare('UPDATE usuario SET username = :username, password = :password, correo = :correo, estado = :estado, rol_id = :rol_id WHERE id = :id');
            $query->execute([
                'id'        => $this->id,
                'username'  => $this->username, 
                'password'  => $this->password,
                'correo'    => $this->correo,
                'estado'    => $this->estado,
                'rol_id'    => $this->rol_id
                ]);
            return true;
        }catch(PDOException $e){
            echo $e;
            return false;
        }
    }

    public function exists($username){
        try{
            $query = $this->prepare('SELECT username FROM usuario WHERE username = :username');
            $query->execute( ['username' => $username]);
            
            if($query->rowCount() > 0){
                return true;
            }else{
                return false;
            }
        }catch(PDOException $e){
            echo $e;
            return false;
        }
    }

    public function from($array){
        $this->id = $array['id'];
        $this->username = $array['username'];
        $this->password = $array['password'];
        $this->correo = $array['correo'];
        $this->estado = $array['estado'];
        $this->rol_id = $array['rol_id'];

    }


    private function getHashedPassword($password){
        return password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
    }

    public function setUsername($username){ $this->username = $username;}
    //FIXME: validar si se requiere el parametro de hash
    public function setPassword($password, $hash = true){ 
        if($hash){
            $this->password = $this->getHashedPassword($password);
        }else{
            $this->password = $password;
        }
    }

    public function setId($id){         $this->id = $id;}
    public function setCorreo($correo){ $this->correo = $correo;}
    public function setEstado($estado){ $this->estado = $estado;}
    public function setRol_id($rol_id){ $this->rol_id = $rol_id;}
    //TODO mejorar
    public function setRole($rol){
        $rol_list = array('user' => '1',
                          'worker' => '2',
                          'admin' => '3');
        $rol_id = $rol_list[$rol];
        $this->setRol_id($rol_id);
    }


    public function getId(){        return $this->id;}
    public function getUsername(){  return $this->username;}
    public function getPassword(){  return $this->password;}
    public function getCorreo(){    return $this->correo;}
    public function getEstado(){    return $this->estado;}
    public function getRol_id(){    return $this->rol_id;}

    //TODO mejorar
    public function getRole(){
        $rol_list = array('1' => 'user',
                     '2' => 'worker',
                     '3' => 'admin');
        return $rol_list[$this->rol_id];
    }

}

?>