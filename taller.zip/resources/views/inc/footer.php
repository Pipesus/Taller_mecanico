<p><?php echo __DIR__ ?></p>    
</body>
</html>