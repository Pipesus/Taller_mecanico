<?php require 'inc/header.php' ?>
<h1>Home</h1>
<p><?php echo __DIR__ ?></p>
<?php require 'inc/footer.php' ?>
<?php 
    $Hola = "Hola mundo";
    echo "$Hola complejo";


?>